//
//  CatchAll.hpp
//  EPI
//
//  Created by Akshay Bhandary on 2/14/16.
//  Copyright © 2016 Axa Labs. All rights reserved.
//

#ifndef CatchAll_hpp
#define CatchAll_hpp

#include <stdio.h>

#endif /* CatchAll_hpp */
