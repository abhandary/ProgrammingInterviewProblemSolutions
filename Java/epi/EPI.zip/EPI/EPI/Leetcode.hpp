//
//  All.hpp
//  EPI
//
//  Created by Akshay Bhandary on 3/6/16.
//  Copyright © 2016 Axa Labs. All rights reserved.
//

#ifndef All_hpp
#define All_hpp

#include <stdio.h>

#endif /* All_hpp */
