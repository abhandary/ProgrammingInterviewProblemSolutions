//
//  pow(x,y).hpp
//  EPI
//
//  Created by Akshay Bhandary on 2/14/16.
//  Copyright © 2016 Axa Labs. All rights reserved.
//

#ifndef pow_x_y__hpp
#define pow_x_y__hpp

#include <stdio.h>

#endif /* pow_x_y__hpp */
