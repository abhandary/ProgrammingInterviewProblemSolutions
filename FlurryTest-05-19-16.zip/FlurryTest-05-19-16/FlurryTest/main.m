//
//  main.m
//  FlurryTest
//
//  Created by Moat 565 on 4/15/16.
//  Copyright © 2016 Moat 565. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
