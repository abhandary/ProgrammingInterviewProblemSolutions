//
//  NativeAdDemo.m
//  FlurryTest
//
//  Created by Moat 565 on 4/15/16.
//  Copyright © 2016 Moat 565. All rights reserved.
//

#import "NativeAdDemo.h"
#import "FlurryAdNative.h"
#import "FlurryAdNativeDelegate.h"

@interface NativeAdDemo () <FlurryAdNativeDelegate>

@property (nonatomic, retain) FlurryAdNative* nativeAd;

@end

@implementation NativeAdDemo

- (void)viewDidLoad
{
    [super viewDidLoad];
    FlurryAdNative *nativeAd = [[FlurryAdNative alloc] initWithSpace:@"ios_native_adspace"];
    //”iOSNativeAd” is configured on dev.flurry.com as a Stream ad space
    
    //Assign the FlurryAdNativeDelegate
    nativeAd.adDelegate = self;
    
    //UIViewController used for presentation of the full screen after the user clicks on the ad
    nativeAd.viewControllerForPresentation = self;
    
    self.nativeAd = nativeAd;
    
    //Request the ad from Flurry.
    [nativeAd fetchAd];
    
    //nativeAd.trackingView = self;
    /*
    if ([FlurryAds adReadyForSpace:@"ios_native_adspace"]) {
        [FlurryAds displayAdForSpace:@"ios_native_adspace" onView:self.view];
    } else {
        [FlurryAds fetchAdForSpace:@"ios_native_adspace" frame:self.view.frame size:IN_FEED];
    }*/
}

-(void)viewDidAppear:(BOOL)animated {
    [self.mainScrollView setContentSize:CGSizeMake(320, 3000)];
}

#pragma mark - FlurryAdNativeDelegate delegates
//The Flurry SDK receives the ad’s assets and calls back ``adNativeDidFetchAd`` with the FlurryAdNative object reference.
- (void) adNativeDidFetchAd:(FlurryAdNative *)nativeAd
{
    NSLog(@"Native Ad for Space [%@] Received Ad with [%lu] assets", nativeAd.space, (unsigned long)nativeAd.assetList.count);
    [self setupAd:nativeAd];
}

//or in case of no ads returned the SDK calls adNAtive:adError:errorDescription
- (void) adNative:(FlurryAdNative*)nativeAd
          adError:(FlurryAdError)adError
 errorDescription:(NSError*) errorDescription
{
    //FLURRY_AD_ERROR_DID_FAIL_TO_RENDER   = 0,
    //FLURRY_AD_ERROR_DID_FAIL_TO_FETCH_AD = 1,
    //FLURRY_AD_ERROR_CLICK_ACTION_FAILED  = 2,
    NSLog(@" Native Ad for Space [%@] Received Error # [%d], with description: [%@]  ================ ", nativeAd.space, adError, errorDescription );
    
}

-(void)setupAd:(FlurryAdNative *)nativeAd {
    for (int ix = 0; ix < nativeAd.assetList.count; ++ix) {
        
        FlurryAdNativeAsset* asset = [nativeAd.assetList objectAtIndex:ix];
        
        if ([asset.name isEqualToString:@"headline"]) {
            self.cardTitleLabel.text = asset.value;
        }
        if ([asset.name isEqualToString:@"summary"]) {
            self.cardSummaryLabel.text = asset.value;
        }
        
        if ([asset.name isEqualToString:@"source"] && asset.value != nil && [asset.value isKindOfClass:[NSString class]]) {
            self.cardSourceLabel.text = asset.value;
        }
        if ([asset.name isEqualToString:@"secHqImage"])
        {
            self.cardRectangleImageView.contentMode = UIViewContentModeScaleAspectFit;
            NSURL * imageURL = [NSURL URLWithString:asset.value];
            NSData * imageData = [NSData dataWithContentsOfURL:imageURL];
            UIImage * image = [UIImage imageWithData:imageData];
            //self.cardRectangleImageView setimage
            [self.cardRectangleImageView setImage:image];
            //[self.cardRectangleImageView setImageWithURL:[NSURL URLWithString:asset.value] placeholderImage:[UIImage imageNamed:@"placeholderImage"]];
        }
    }
    self.cardSponsoredLabel.text = @"SPONSORED";
    
    if ([nativeAd isVideoAd]) {
        
        nativeAd.videoViewContainer =  self.cardRectangleVideoViewContainer;
        self.cardRectangleVideoViewContainer.hidden = NO;
        self.cardRectangleImageView.hidden = YES;
    }
    else {
        NSLog(@"not video");
    }
    
    nativeAd.trackingView = self.cardView;
}

@end
