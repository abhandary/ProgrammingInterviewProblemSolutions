//
//  ViewController.m
//  FlurryTest
//
//  Created by Moat 565 on 4/15/16.
//  Copyright © 2016 Moat 565. All rights reserved.
//

#import "ViewController.h"
#import "FlurryAdInterstitial.h"
#import "FlurryAdInterstitialDelegate.h"

@interface ViewController () <FlurryAdInterstitialDelegate>
@property (nonatomic, strong) FlurryAdInterstitial* adInterstitial;

@end


@implementation ViewController

@synthesize adInterstitial;
// the adSpaceName refers to the ad space configured on dev.flurry.com under Publishers tab
// under left-hand nav Inventory / Ad Spaces
//NSString *adSpaceName = @"video_adspace";
NSString *adSpaceName = @"ios_video_adspace";


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    // Fetch fullscreen ads early when a later display is likely. For
    // example, at the beginning of a level.
    adInterstitial = [[FlurryAdInterstitial alloc]  initWithSpace:adSpaceName];
    adInterstitial.adDelegate = self;
    
    
}

-(void) viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    // Do not set ad delegate to nil and
    // Do not remove ad in the viewWillDisappear or viewDidDisappear method
}

/**
 * Invoke a takeover at a natural pause in your app. For example, when a
 * level is completed, an article is read or a button is pressed. We will
 * mock the display of a takeover when a button is pressed.
 */
-(IBAction) showFullScreenAdClickedButton:(id)sender
{
    // Check if ad is ready. If so, display the ad
    
    if ([adInterstitial ready]) {
        [adInterstitial presentWithViewController:self];
    } else {
        [adInterstitial fetchAd];
    }
}

#pragma mark - adInterstitial delegates

//Invoked when an ad is received for the specified  interstitialAd object.
- (void) adInterstitialDidFetchAd:(FlurryAdInterstitial*)interstitialAd
{
    // you can choose to present the ad as soon as it is received
    [interstitialAd presentWithViewController:self];
}

//  Invoked when the interstitial ad is rendered.
- (void) adInterstitialDidRender:(FlurryAdInterstitial *)interstitialAd
{
    
}

//Informs the app that a video associated with this ad has finished playing.
//Only present for rewarded & client-side rewarded ad spaces
- (void) adInterstitialVideoDidFinish:(FlurryAdInterstitial *)interstitialAd
{
    
}

//Informational callback invoked when there is an ad error
- (void) adInterstitial:(FlurryAdInterstitial*)interstitialAd
                adError:(FlurryAdError) adError
       errorDescription:(NSError*) errorDescription
{
    // @param interstitialAd The interstitial ad object associated with the error
    // @param adError an enum that gives the reason for the error.
    // @param errorDescription An error object that gives additional information on the cause of the ad error.
}

@end


