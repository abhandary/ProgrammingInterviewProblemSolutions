//
//  NativeAdDemo.h
//  FlurryTest
//
//  Created by Moat 565 on 4/15/16.
//  Copyright © 2016 Moat 565. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NativeAdDemo : UIViewController

@property (unsafe_unretained, nonatomic) IBOutlet UIView *cardView;
@property (unsafe_unretained, nonatomic) IBOutlet UILabel *cardTitleLabel;
@property (unsafe_unretained, nonatomic) IBOutlet UILabel *cardSummaryLabel;

@property (unsafe_unretained, nonatomic) IBOutlet UILabel *cardSourceLabel;
@property (unsafe_unretained, nonatomic) IBOutlet UIImageView *sponseredImageView;
@property (weak, nonatomic) IBOutlet UILabel *cardSponsoredLabel;

@property (unsafe_unretained, nonatomic) IBOutlet UIImageView *cardRectangleImageView;

@property (weak, nonatomic) IBOutlet UIView *containerView;
@property (weak, nonatomic) IBOutlet UIView *topColorView1;
@property (weak, nonatomic) IBOutlet UIView *topColorView2;

//this UIView overlaps cardRectangleImageView. It could be used for
//presenting a video ad, otherwise it can be hidden
//
@property (weak, nonatomic) IBOutlet UIView *cardRectangleVideoViewContainer;
@property (weak, nonatomic) IBOutlet UIScrollView *mainScrollView;

@end
