//
//  AppDelegate.h
//  FlurryTest
//
//  Created by Moat 565 on 4/15/16.
//  Copyright © 2016 Moat 565. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

